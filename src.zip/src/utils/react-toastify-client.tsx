"use client";

import "react-toastify/dist/ReactToastify.css";
import {ToastContainer} from "react-toastify";

interface ToastProviderProps {
    children: React.ReactNode;
}

export default function ToastProvider({children}: ToastProviderProps) {
    const contextClass = {
        success: "bg-blue-600",
        error: "bg-red-600",
        info: "bg-gray-600",
        warning: "bg-orange-400",
        default: "bg-indigo-600",
        dark: "bg-white-600 font-gray-300",
    };
    return (
        <>
            {children}
            <ToastContainer
                toastClassName={(context) =>
                    context.defaultClassName+ " "+contextClass[context?.type || "default"]
                }
                // bodyClassName={() => "text-sm font-bYekan p-3"}
                position="top-right"
                rtl
                autoClose={3000}
            />
        </>
    );
}